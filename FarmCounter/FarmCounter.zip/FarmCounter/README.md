# Farm Counter
A simple farm counter to keep track of how many times you have run a certain farm. The settings for Farm Counter can all be configured in the mod settings menu.

You will need to download [User Feedback](https://bl-sdk.github.io/mods/UserFeedback/) for this to work

Thankyou pyrex for their help.