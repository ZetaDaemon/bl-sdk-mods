# Farm Counter
A simple farm counter to keep track of how many times you have run a certain farm. The settings for Farm Counter can all be configured in the mod settings menu.

You will need to download [User Feedback](https://bl-sdk.github.io/mods/UserFeedback/) for this to work.

### v1.1
Added a manual display mode that writes the farm counter to a text file inside the mod folder for use with overlays in OBS and such.

### v1.0
Initial Release.

Thankyou pyrex for their help.