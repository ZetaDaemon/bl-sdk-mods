# Reward Reroller
Lets you reroll mission rewards at the cost of eridium. In multiplayer all players will be promted with the mission reward screen to reroll their own items.

Thankyou to Flare2V and alienoliver for the original work in BL2Fix.

### v1.0
Initial Release.
