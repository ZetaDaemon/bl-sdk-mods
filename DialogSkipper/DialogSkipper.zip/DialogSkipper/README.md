# Dialog Skipper
Allows dialog to be skipped by pressing a keybind, defaults to Z.

Additionally, allows for the option to automatically skip all dialog so it never plays.

### v1.0
Initial Release.