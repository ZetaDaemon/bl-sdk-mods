# Console Font Size
Gives a slider in the mod settings to adjust the console font size.

### v1.0
Initial Release.
