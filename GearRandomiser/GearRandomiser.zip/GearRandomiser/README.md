# Gear Randomiser
Randomises all gear in the game for some whacky combo's.  
Adds options to select which character classmods will be set for as well as a chaos mode which removes restrictions as to what part goes where on guns.

You will need to download [Structs](https://bl-sdk.github.io/mods/Structs/) and [Sanity Saver](https://bl-sdk.github.io/mods/SanitySaver/) for this to work.

### v1.0
Initial Release.