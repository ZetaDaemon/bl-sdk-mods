# Zeta's Commands
An mod that is an extention to [Command Extentions](https://bl-sdk.github.io/mods/CommandExtensions/) adding some more commands that can be used in blcmm files.

[See here for info on the commands and how to write mods using them.](Writing-Mods.md)