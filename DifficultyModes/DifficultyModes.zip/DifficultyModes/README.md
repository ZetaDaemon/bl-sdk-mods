# Difficulty Modes
Replaces BAR with a difficulty mode that can be changed in the options.

BAR stats and redeeming BAR tokens is disabled while the mod is active, but BAR needs to be on for the effects of the mod to work.

Easy has weaker and less aggressive enemies than vanilla. Normal has no modifiers to play at vanilla balance. Medium, Hard and Nightmare increasingly makes enemies tougher and more aggressive.

You will need to download [Enums](https://bl-sdk.github.io/mods/Enums/) and [Structs](https://bl-sdk.github.io/mods/Structs/) for this to work.

### v1.0
Initial Release.